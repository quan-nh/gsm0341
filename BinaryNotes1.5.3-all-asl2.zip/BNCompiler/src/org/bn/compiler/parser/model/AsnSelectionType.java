package org.bn.compiler.parser.model;

public class AsnSelectionType {
    public String name;
    public String selectionID;
    public Object type;

    //~--- constructors -------------------------------------------------------

    // Default Constructor
    public AsnSelectionType() {}

    //~--- methods ------------------------------------------------------------

    // toString Method
    public String toString() {
        String ts = "";

        // Define To String Method
        return ts;
    }
}
